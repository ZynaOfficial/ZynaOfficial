
exports.infoOwner = () =>{
return`「 𝗗𝗔𝗧𝗔 𝗣𝗥𝗢𝗙𝗜𝗟 𝗢𝗪𝗡𝗘𝗥 」

 ⬣  𝗡𝗮𝗺𝗮: 𝖅𝖞𝖓𝖆𝕺𝖋𝖋𝖎𝖈𝖎𝖆𝖑
 ⬣  𝗨𝗺𝘂𝗿: 15
 ⬣  𝗛𝗼𝗯𝘆: Habisin duit ortu
 ⬣  𝗔𝘀𝗮𝗹: Jabar - subang
 ⬣  𝗦𝘁𝗮𝘁𝘂𝘀: Creator
 ⬣  𝗭𝗼𝗱𝗶𝗮𝗸: Virgo

                  「 𝗦𝗢𝗦𝗜𝗔𝗟 𝗠𝗘𝗗𝗜𝗔 」
 ⬣  𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽: 085721627486
 ⬣  𝗬𝗼𝘂𝘁𝘂𝗯𝗲: youtube.com/@ZynaOfficial
 ⬣  𝗚𝗶𝘁𝗵𝘂𝗯: github.com/ZyNaBotz-XD
 ⬣  𝗜𝗻𝘀𝘁𝗮𝗴𝗿𝗮𝗺: Instagram.com/@zynaofficial
 ⬣  𝘄𝗲𝗯𝘀𝗶𝘁𝗲: 𝖅𝖞𝖓𝖆𝕺𝖋𝖋𝖎𝖈𝖎𝖆𝖑
 `
}